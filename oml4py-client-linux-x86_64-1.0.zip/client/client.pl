#!/usr/local/bin/perl
# 
# $Header: oraml/python/OPE/install/client/client.pl /st_oraml_18.1.0.0.0/1 2020/01/22 07:11:28 yuxian Exp $
#
# client.pl
# 
# Copyright (c) 2018, 2020, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      client.pl - OML4P CLIENT installation script
#
#    DESCRIPTION
#      OML4P client installation, upgrade, uninstallation and setup.
#
#    NOTES
#
#    MODIFIED   (MM/DD/YY)
#    yuxian      01/16/20 - Add prebuilt-pkgs
#    yuxian      04/18/19 - By default do not download dependencies
#                           and undoc --deps
#    andiwang    02/04/19 - Update dist_name
#    qinwan      01/17/19 - install embed by default
#    andiwang    11/27/18 - Fix wheel_name
#    yuxian      09/27/18 - add automl install/uninstall
#    andiwang    07/24/18 - Change script to install wheel
#    andiwang    05/31/18 - Client installation script
#    andiwang    05/31/18 - Creation
# 
use strict;
use warnings;
use OML4PInstallShared;

# -----------------------------------------------------------------------------
# Helper function. Print usage screen.
#
sub usage {
  my $message = <<"END_MESSAGE";
Usage: client.pl [OPTION]...
Install, upgrade, or uninstall OML4P Client.

  -i, --install             install or upgrade (default)
  -u, --uninstall           uninstall
  -y                        never prompt
  --ask                     interactive mode (default)
  --no-embed                do not install embedded python functionality
  --no-automl               do not install automl module
  --no-deps                 turn off dependencies checking
  --target <dir>            install client into <dir> 
END_MESSAGE

  print $message;
}

# -----------------------------------------------------------------------------
# Banner.
#
print "\n";
print "Oracle Machine Learning for Python ".OML4P_VER." Client.\n";
print "\n";
print "Copyright (c) 2018, ".OML4P_YEAR." Oracle and/or its affiliates. " ,
  "All rights reserved.";
print "\n";

# -----------------------------------------------------------------------------
# Defaults.
#
my $install=1;
my $uninstall=0;
my $interactive=1;
my $check_deps=1;
my $deps_install=0;
my $target='';
my $PREBUILT_DIR='';
my $oml4p_mode="None";
my $sep = get_sep();
my $embed=1;
my $automl=1;

# -----------------------------------------------------------------------------
# Command line arguments.
#
while (@ARGV) {
  my $argument = shift(@ARGV);
  if ($argument eq "-i" || $argument eq "--install") {
    $install=1; $uninstall=0
  } elsif ($argument eq "-u" || $argument eq "--uninstall") {
    $install=0; $uninstall=1
  } elsif ($argument eq "--no-embed") {
    $embed = 0
  } elsif ($argument eq "--no-automl") {
    $automl = 0
  } elsif ($argument eq "-y") {
    $interactive=0
  } elsif ($argument eq "--ask") {
    $interactive=1
  } elsif ($argument eq "--no-deps") {
    $check_deps=0
  } elsif ($argument eq "--deps") {
    $deps_install=1
  } elsif ($argument eq "--target") {
    die "ERROR: must specify a non-empty \"--target <dir>\" argument" unless @ARGV;
    $target=shift(@ARGV);
  } elsif ($argument eq "--prebuilt-pkgs") {
    die "ERROR: must specify a non-empty \"--prebuild-pkgs <DIR>\" argument" unless @ARGV;
    $PREBUILT_DIR=shift(@ARGV);
  } elsif ($argument eq "-h" || $argument eq "--help") {
    usage(); exit
  } else {usage(); exit 1}
}

# -----------------------------------------------------------------------------
# Mode.
#
if ($install) {
  $oml4p_mode="Install/Upgrade";
} elsif ($uninstall) {
  $oml4p_mode="Uninstall"
}

remove_preexist();
my $OML4P_PLATFORM = check_platform();

# -----------------------------------------------------------------------------
# If Python is available on the PATH - use it. Otherwise look for PYTHONHOME
# variable and if it is set try to find Python there. PYTHONCMD variable is set
# to the absolute path to Python. After PYTHONCMD is set PYTHONHOME is reset the
# second time to deal with possible symlink problems.
# PYTHONHOME is not exported to ensure that multiple versions of Python can run
# without PYTHONHOME warnings.
#
print "Checking Python .................... ";
(my $PYTHONHOME, my $PYTHONCMD, my $py_version) = get_python_cmd();

print "Pass\n";

# -----------------------------------------------------------------------------
# Check dependencies has been installed if deps_install=0.
#
if ($check_deps && $PREBUILT_DIR eq "" && not $deps_install) {
    print "Checking dependencies .............. ";
    my $deps_result = deps_check($PYTHONCMD);
    if ($deps_result ne 'Pass') {
      die "Fail\n  ERROR: $deps_result"
    }
    print "Pass\n";
}

# -----------------------------------------------------------------------------
# Check what version of the OML4P client has been installed.
#
print "Checking OML4P version ............. ";
my $libs_version = lookup_oml4p_ver_str($PYTHONCMD);
my $libs_remove = oml4p_version($libs_version);
my $libs_install=1;
if ($libs_remove == OML4P_VER_BAD) {
  die "Fail\n  ERROR: a later version of OML4P $libs_version " .
      "is already installed"
} elsif ($libs_remove == OML4P_VER_NUM) {
  $libs_remove=0;
} elsif ($libs_remove == 0) {
  $libs_version="None"
}

# Prepare for uninstall. 
#
if ($uninstall) {
  $libs_remove=OML4P_VER_NUM;
  $libs_install=0;

  $deps_install=0;
}
print "Pass\n";

# -----------------------------------------------------------------------------
# Print current configuration and ask whether to proceed.
#
print "Current configuration\n";
print "  Python Version ................... $py_version\n";
print "  PYTHONHOME ....................... $PYTHONHOME\n";
print "  Existing OML4P module version .... $libs_version\n";
if ($target && $libs_install) {
print "  Installation location ............ $target\n";
}
if ($install)
{
  if ($deps_install) {
print "  Download missing dependencies .... Enabled\n";
  }
}

print "\n  Operation ........................ $oml4p_mode\n";

if ($interactive) {
  while (1) {
    print "\nProceed? [yes]";
    chomp(my $yn = <STDIN>);
    if ($yn eq "") {
      $yn="yes"
    }
    if (lc(substr($yn, 0, 1)) eq 'n') {
      exit 1;
    } elsif (lc(substr($yn, 0, 1)) eq 'y') {
      last;
    } else {
      print "Please answer yes or no.\n";
    }
  }
}

print "\n";

# -----------------------------------------------------------------------------
# Remove packages.
#
if ($libs_remove) {
  uninstall_mod($PYTHONCMD)
}

# -----------------------------------------------------------------------------
# Install packages.
#
if ($libs_install) {
  my $whl = "client${sep}".dist_name($py_version, 'oml', OML4P_VER, 'ol_wheel');

  if (not $embed) {
    $whl = remove_mod('embed', $py_version, $whl);
  }

  if (not $automl) {
    $whl = remove_mod('automl', $py_version, $whl);
  }

  if ($deps_install) {
    my $deps_result = deps_check($PYTHONCMD);

    if ($deps_result eq 'Pass') {
      $deps_install = 0;
    }
  }

  if ($PREBUILT_DIR ne "") {
    install_deps($PYTHONCMD, $target, $PREBUILT_DIR, $py_version);
  }

  install_mod($PYTHONCMD, $target, $deps_install, $whl);

  if ((not $embed) || (not $automl)) {
    unlink ${whl}
  }
}

# -----------------------------------------------------------------------------
# Final words.
#

print "\nDone\n";

