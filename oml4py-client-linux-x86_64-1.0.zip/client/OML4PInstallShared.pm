# 
# $Header: oraml/python/OPE/install/OML4PInstallShared.pm qinwan_std1dot0_release/2 2022/02/22 07:36:52 qinwan Exp $
#
# Shared.pm
# 
# Copyright (c) 2018, 2022, Oracle and/or its affiliates. 
#
#    NAME
#      OML4PInstallShared.pm - OML4P SHARED INSTALLation code
#
#    DESCRIPTION
#      Code for OML4P installation shared between different components
#
#    NOTES
#
#    MODIFIED   (MM/DD/YY)
#    qinwan      02/16/22 - Update numpy scikit-learn package versions
#    qinwan      01/04/22 - upgrade pandas joblib versions
#    yuxian      07/02/21 - Fix support pkg wheel suffix
#    qinwan      03/19/21 - include threadpoolctl in supporting package
#    qinwan      10/13/20 - update python module versions
#    yuxian      01/28/20 - Upgrade dep pkgs
#    yuxian      01/17/20 - Add install_deps subroutine
#    yuxian      08/14/19 - Upgrading Numpy to 1.16.3
#    yuxian      08/08/19 - Persist script module w/ --no-embed
#    andiwang    05/06/19 - Fix case when executable is in a folder with a
#                           space
#    yuxian      04/18/19 - release year num update & import catch
#    yuxian      03/07/19 - Fix windows case for dist_name
#    andiwang    02/05/19 - Change file permissions for temp files
#    andiwang    02/04/19 - Make check_deps more informative
#    andiwang    11/27/18 - Make check_deps shorter and more universal
#    andiwang    11/09/18 - Enable install_mod to install arbitrary modules
#    yuxian      09/27/18 - add remove_mod to remove modules from whl
#    yuxian      09/07/18 - Correct version checking for pyreadline
#    andiwang    07/24/18 - Add embed arg to install_mod
#    andiwang    06/06/18 - Shared install code
#    andiwang    06/06/18 - Creation
#

package OML4PInstallShared;
use strict;
use warnings;
use Cwd 'abs_path';
use File::Path 'mkpath';
use File::Path 'rmtree';
use File::Copy;

our $VERSION = '1.0';

use base 'Exporter';

our @EXPORT = qw(OML4P_YEAR OML4P_VER OML4P_VER_NUM OML4P_VER_BAD @DEPS 
                 oml4p_version oml4p_release num_pad write_tmp_file
                 write_result_to_log remove_preexist check_platform
                 get_python_cmd dist_name lookup_oml4p_ver_str get_sep
                 install_deps install_mod uninstall_mod deps_check remove_mod);

# -------------------------------------------------------------------------------
# Generic setup. When moving to the next release update OML4P_YEAR to the year
# of  the release, OML4P_VER to the official version number and OML4P_VER_NUM to
# the sequential number. Additionally functions oml4p_version and oml4p_release
# should be updated to recognize the new version number. New libraries and
# packages are defined in the section that follows the print out of the current
# configuration.
#

use constant {
  OML4P_YEAR => 2022,
  OML4P_VER => "1.0",
  OML4P_VER_NUM => 1,
  OML4P_VER_BAD => 127
};

our @DEPS = (["numpy", "1.21.5", "wheel"],
             ["pandas", "1.3.4", "wheel"],
             ["scipy", "1.7.3", "wheel"],
             ["matplotlib", "3.3.3", "wheel"],
             ["cx_Oracle", "8.1.0", "wheel"]);
if ($^O eq "MSWin32") {
  push @DEPS, ["pyreadline", "2.1", "zip"];
}


sub oml4p_version {
  if ($_[0] eq "1.0") {
    return 1
  } elsif ($_[0] eq "0.0") {
    return 0
  } elsif ($_[0] == -1) {
    die "Fail\n  ERROR: import oml failed."
  } else {
    return OML4P_VER_BAD
  }
};

sub oml4p_release {
  if ($_[0] == 1){
    return "1.0 ............."
  } elsif ($_[0] == 0){
    return "0.0 ............."
  } else {
    return "................."
  }
};

# -----------------------------------------------------------------------------
# Helper function. Zero pad numbers to two digit strings. The results is
# returned in num_pad_ret variable.
#
sub num_pad {
  my $num = $_[0];
  if ($num == 0) {
    return "00"
  } elsif ($num < 9 ) {
    return "0$num"
  } else {
    return $num
  }
};

# -----------------------------------------------------------------------------
# Helper function. Write text to a temporary file. The first argument is the
# text, and the second argument is the name of the temporary file.
#
sub write_tmp_file {
  open (my $tmp_handle, '>', $_[1]);
  print $tmp_handle $_[0];
  close $tmp_handle;
  chmod 0440, $_[1];
}

# -----------------------------------------------------------------------------
# Helper function. Write array of lines to a temporary file. The first argument
# is the text as the reference to an array, and the second argument is the name
# of the log file.
#
sub write_result_to_log {
  open (my $tmp_handle, '>', $_[1]);
  my @data = @{$_[0]};
  foreach (@data) {
    print $tmp_handle "$_";
  }
  close $_[1];
  chmod 0440, $_[1];
}

# -----------------------------------------------------------------------------
# Remove pre-existing tmp*.sql from installation dir
sub remove_preexist {
  my @preexist_tmp = glob("tmp*.sql");
  if (@preexist_tmp) {
    unlink glob "tmp*.sql";
    die "Fail\n  ERROR: Failed to remove pre-existing tmp*.sql" unless $! == 0;
  }
}

# -----------------------------------------------------------------------------
# Platform check. OML4P_PLATFORM is set to a platform specific string used in
# naming python wheels.
#
#TODO: support AIX and SUNOS/SPARC

sub check_platform {
  unless (defined $_[0]) {
    print "Checking platform .................. ";
  }

  my $OML4P_PLATFORM;
  if ($^O eq "linux") {
    $OML4P_PLATFORM="linux_x86_64"
  } elsif ($^O eq "MSWin32") {
    $OML4P_PLATFORM="win_amd64"
  } else {
    die "Fail\n  ERROR: platform \"$^O\" is not supported"
  }

  unless (defined $_[0]) {
    print "Pass\n";
  }
  return $OML4P_PLATFORM;
}

sub get_python_cmd {
  use Env '@PATH';
  @PATH = grep { defined $_ } @PATH;
  my @python_exists = ();
  my $PYTHONHOME=$ENV{PYTHONHOME};
  my $PYTHONCMD;
  if ($^O eq "MSWin32") {
    @python_exists = grep -x "$_/python.exe",@PATH;
    if (@python_exists) {
      $PYTHONCMD = $python_exists[0].'/python.exe'; 
    }
  } else {
    @python_exists = grep -x "$_/python3",@PATH;
    if (@python_exists) {
      $PYTHONCMD = $python_exists[0].'/python3'; 
    } else {
      @python_exists = grep -x "$_/python",@PATH;
      if (@python_exists) {
        $PYTHONCMD = $python_exists[0].'/python'; 
      }
    }
  }

  if (!@python_exists) {
    if ($PYTHONHOME) {
      if ($^O eq "MSWin32") {
        $PYTHONCMD="$PYTHONHOME/bin/python.exe";
        unless (-f $PYTHONCMD) {
          $PYTHONCMD="$PYTHONHOME/python.exe"
        }
      } else {
        $PYTHONCMD="$PYTHONHOME/bin/python3";
        unless (-f $PYTHONCMD) { 
          $PYTHONCMD="$PYTHONHOME/bin/python"
        }
      }
    } else {
      die "Fail\n  ERROR: Python not found"
    }
  }

  unless (-f $PYTHONCMD) {
    die "Fail\n  ERROR: Python not found"
  }
  
  $PYTHONCMD="\"$PYTHONCMD\"";
  my $tmp_file = "check_oml4p.py";
  my $query = <<"EOF";
import sys
if sys.prefix == sys.exec_prefix:
  print(sys.prefix)
else:
  print(sys.prefix + ':' + sys.exec_prefix)
EOF

  write_tmp_file($query, $tmp_file);
  chomp($PYTHONHOME=`$PYTHONCMD  $tmp_file`);
  unlink $tmp_file;

  chomp(my $py_version = substr(`$PYTHONCMD --version`, 7));

# -----------------------------------------------------------------------------
# Check if Python version is 3.9.5 or later
  my @version_info = split(/\./, $py_version);

  my $pyver_chk = 1;
  if ($version_info[0] < 3) {
    $pyver_chk = 0;
  } elsif ($version_info[0] == 3) {
    if ($version_info[1] < 9) {
      $pyver_chk = 0;
    } elsif ($version_info[1] == 9 && $version_info[2] < 5) {
      $pyver_chk = 0;
    }
  }

  if ($pyver_chk == 0) {
    die "Fail\n ERROR: OML4P ".OML4P_VER." requires Python 3.9.5 or later"
  }

  return ($PYTHONHOME, $PYTHONCMD, $py_version);
}

sub lookup_oml4p_ver_str {
  my $tmp_file = "check_oml4p.py";
  my $query = <<"EOF";
from importlib import util
if util.find_spec("oml") is None:
  print('0.0')
else:
  try:
    import oml
    print(oml.__version__)
  except:
    print(-1)
EOF

  write_tmp_file($query, $tmp_file);
  chomp(my $libs_version=`$_[0]  $tmp_file`);
  unlink $tmp_file;
  return $libs_version
}

sub get_sep {
  my $sep = '/';
  if ($^O eq "MSWin32") {
    $sep = '\\\\';
  }
  return $sep
}

sub deps_check {
  my $dict_str = '';
  foreach my $dep (@DEPS) {
    $dict_str = $dict_str."'".$dep->[0]."':'".$dep->[1]."', ";
  }
  $dict_str = $dict_str."'scikit-learn':'1.0.1'";
  my $tmp_file = "check_deps.py";
my $query = <<"EOF";
def verify_module(mods):
  from pkg_resources import WorkingSet, VersionConflict, DistributionNotFound
  working_set = WorkingSet()
  for key, value in mods.items():
    try:
      dep = working_set.require('%s>=%s' % (key, value))
    except DistributionNotFound:
      print ('Install version %s or higher of %s' % (value, key))
      return
    except VersionConflict as err:
      print ('Upgrade %s from version %s to version %s or higher' %
             (key, err.dist.version, value))
      return
  print('Pass')

verify_module({$dict_str})
EOF

  write_tmp_file($query, $tmp_file);
  chomp(my $deps_result=`$_[0]  $tmp_file`);
  unlink $tmp_file;

  return $deps_result;
}

sub dist_name {
  my $py_version = $_[0];
  my $mod_name = $_[1];
  my $dist_ver = $_[2];
  my $pkg_type = $_[3];
  my $machine = check_platform("False");
  my @version_info = split(/\./, $py_version);
  if ($^O eq "MSWin32" and $pkg_type eq "ol_wheel") {
    $pkg_type = "wheel";
  }

  my $short_ver = $version_info[0].$version_info[1];

  if ($pkg_type eq 'wheel') {
    return $mod_name.'-'.$dist_ver."-cp${short_ver}-cp${short_ver}-".$machine.'.whl';
  } elsif ($pkg_type eq 'wheel_none') {
    return $mod_name.'-'.$dist_ver."-cp${short_ver}-none-".$machine.'.whl';
  } elsif ($pkg_type eq 'ol_wheel') {
    return $mod_name.'-'.$dist_ver."-cp${short_ver}-cp${short_ver}-".'linux_x86_64.whl';
  } elsif ($pkg_type eq 'zip') {
    return $mod_name.'-'.$dist_ver.'.zip';
  } elsif ($pkg_type eq 'py3_none') {
    return $mod_name.'-'.$dist_ver.'-py3-none-any.whl';
  } else {
    return $mod_name.'-'.$dist_ver.'-py2.py3-none-any.whl';
  }
}

sub remove_mod {
  my $sep = get_sep();
  # Component needs to be removed: 'embed' or 'automl'
  my $mod = $_[0];
  my $py_version = $_[1];
  my $path_to_whl = $_[2];
  my $dist_name = dist_name($py_version, 'oml', OML4P_VER, 'wheel');
  # Modules to be removed from oml package
  my @mod_names;

  if ($mod eq 'embed') {
    push @mod_names, 'embed'
  } elsif ($mod eq 'automl') {
    push @mod_names, 'automl'
  } else {
    die "Fail\n  ERROR: cannot remove module '$mod' ".
                        "or module '$mod' not found\n"
  }

  # Unzip whl file, remove optional packages that users don't want to install
  # repackage the rest oml modules into a temp whl file in the current directory
  # to be used in future oml module installation.
  system("unzip -q $path_to_whl -d tmpoml");
  if ($? != 0) {
    die "Fail\n  ERROR: cannot decompress wheel\n"
  }

  chdir('tmpoml');
  
  foreach my $mod_nm (@mod_names) {
    rmtree "oml${sep}$mod_nm"
  }

  my $dist_info_dir = "oml-".OML4P_VER.'.dist-info';
  open (my $records_hdl, '+<', "${dist_info_dir}${sep}RECORD") or die $!;
  my @nentries = grep(!/$mod_names[0]/, <$records_hdl>);
  foreach my $i (1 .. $#mod_names) {
    @nentries = grep(!/$mod_names[$i]/, @nentries);
  }
  print $records_hdl @nentries;
  close $records_hdl;

  my $new_whl_dest = "..${sep}${dist_name}";
  if (-f $new_whl_dest) {
    unlink $new_whl_dest;
  }
  system("zip -q ${new_whl_dest} -r oml ${dist_info_dir}");
  if ($? != 0) {
    die "Fail\n  ERROR: cannot repackage wheel \n"
  }

  chdir('..');
  rmtree 'tmpoml';

  # Return relative path to new whl file
  return $dist_name
}

sub install_deps {
  my $sep = get_sep();
  my $PYTHONCMD = $_[0];
  my $target = $_[1];
  my $PREBUILT_DIR = $_[2];
  my $py_version = $_[3];
  my @all_deps = (["pyparsing", "2.4.0", "pure"], ["six", "1.13.0", "pure"],
                  ["python_dateutil", "2.8.1", "pure"], ["pytz", "2019.3", "pure"],
                  ["cycler", "0.10.0", "pure"], ["joblib", "1.1.0", "pure"],
                  ["kiwisolver", "1.1.0", "wheel"], ["Pillow", "8.2.0", "wheel"]);
  push @all_deps, @DEPS;
  push @all_deps, (["threadpoolctl", "2.1.0", "pure"], ['scikit_learn', '1.0.1', 'wheel']);
  foreach my $dep (@all_deps) {
    my $dist_name = $PREBUILT_DIR.$sep.dist_name($py_version,
                      $dep->[0], $dep->[1], $dep->[2]);
    # pure dep wheel name can be -cp39-none- or -cp39-cp39-
    if ($dep->[2] eq 'wheel') {
      if (! -f $dist_name) {
        $dist_name = $PREBUILT_DIR.$sep.dist_name($py_version,
                       $dep->[0], $dep->[1], "wheel_none");
      }
    }
    # pure dep wheel name can be -py2.py3-none or -py3-none-
    if ($dep->[2] eq 'pure') {
      if (! -f $dist_name) {
        $dist_name = $PREBUILT_DIR.$sep.dist_name($py_version,
                       $dep->[0], $dep->[1], "py3_none");
      }
    }
    install_mod($PYTHONCMD, $target, 0, $dist_name);
  }
}

sub install_mod {
  my $sep = get_sep();
  my $PYTHONCMD = $_[0];
  my $target = $_[1];
  my $deps_install = $_[2];
  my @dist_parts = split('-', $_[3]);
  my $mod_name = $dist_parts[0];

  my $install_cmd = "$PYTHONCMD -m pip install --upgrade $_[3]";

  if ($target ne ''){
    if (not -d $target){
      mkpath($target) or die "Fail\n  ERROR: cannot create $target\n";
    }
    $target = abs_path($target);
    #the pip --target argument is not being used because when the --target argument 
    #is used, then weirdly, pip becomes unable to detect installed dependencies
    $install_cmd = $install_cmd . " --target=$target";
  }

  if (not $deps_install) {
    $install_cmd = $install_cmd . " --no-deps";
  } 

  system($install_cmd);
  if ($? != 0) {
    print "Fail\n  ERROR: cannot install module $mod_name\n"
  }
}

sub uninstall_mod {
  system("$_[0] -m pip uninstall -y oml");
  if ($? != 0) {
    print "Fail\n  ERROR: cannot remove module oml\n"
  }
}
1;
